# スタートガイド — 業務管理ダッシュボードPRO

版: 1.0.0 / 生成日: 2026-10-21

## 同梱物

| ファイル | 説明 |
|----------|------|
| operations_desk_pro_empty.xlsx | 空データ版（本番入力用） |
| operations_desk_pro_sample.xlsx | 架空サンプル入り |
| START_GUIDE.md | 本ファイル |
| TERMS.txt | 利用条件 |
| CHANGELOG.txt | 更新履歴 |
| sheets_to_google.md | Googleスプレッドシート移植の注意 |

## 5分セットアップ

1. `operations_desk_pro_empty.xlsx` を Microsoft 365 Excel で開く
2. 「設定」で検証日を今日（または締め日）に合わせる
3. 「顧客」→「案件」→「請求」の順に入力（黄色いセル）
4. 「ダッシュボード」で未入金・遅延を確認

## 計算の定義

- **売上**: 案件の状態が 受注 / 進行中 / 納品済 / 完了 の金額合計（請求額ではない）
- **未入金**: 入金状態が「未入金」の請求額合計（部分入金は非対応）
- **遅延**: 未入金かつ支払期日 < 設定の検証日

## 対応環境

優先検証: Microsoft 365 デスクトップ Excel（Windows）。  
Google スプレッドシートは数式・グラフの互換差あり（`sheets_to_google.md`）。

## サポート範囲

個別カスタマイズ・設定代行は提供しません。FAQ と本ガイドをご利用ください。
